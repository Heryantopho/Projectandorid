package com.example.kuisapplikasifinal;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class Register extends Activity {
    Database db;
    int id;
    String username, fullname, password, address, email, phone, conpass = null;
    SmsManager smsManager;
    int smsPermissionSend;
    int random;
    String a;
    Button register;
    EditText usernamereg, fullnamereg, passreg, addressreg, emailreg, phonenumberreg, confirmpassreg;
    public static ArrayList<Mahasiswa> mahasiswaArray = new ArrayList<Mahasiswa>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new Database(this);

        passreg = findViewById(R.id.passtxtregis);
        usernamereg = findViewById(R.id.usernametxtregis);
        fullnamereg = findViewById(R.id.fullnametxtregis);
        addressreg = findViewById(R.id.addresstxtregis);
        emailreg = findViewById(R.id.emailtxtregis);
        phonenumberreg = findViewById(R.id.phonetxtregis);
        confirmpassreg = findViewById(R.id.conpasstxtregis);
        random = (int)(Math.random() * 9900 + 1);
        random += 5000;
        // int a = random;
        a = Integer.toString(random);

        register = (Button) findViewById(R.id.registerbtn);

        smsPermissionSend = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        smsManager = SmsManager.getDefault();
        // if (smsPermissionSend != PackageManager.PERMISSION_GRANTED) {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                id = (mahasiswaArray.size()+1);
              username = usernamereg.getText().toString();
                fullname = fullnamereg.getText().toString();
                password = passreg.getText().toString();
                address = addressreg.getText().toString();
                email = emailreg.getText().toString();
                conpass = confirmpassreg.getText().toString();
             phone = phonenumberreg.getText().toString();

                if(username.length()<=3){
                    usernamereg.setError("Must more than 3 Character");
                }

                else if(fullname.equals("")){
                    fullnamereg.setError("Must be fill");
                }

                else if(chckpassword(password)){
                    passreg.setError("Must follow password Format");
                }

                else if(!conpass.equals(password)){
                    confirmpassreg.setError("Confirm password tidak sesuai dengan password");
                }

                else if(address.equals("")) {
                    addressreg.setError("Must Be Fill");
                }

                else if(!email.endsWith("bookparadise.com")){
                    emailreg.setError("Email harus berakhir @bookparadise.com");
                }

                else if(!chcknumber(phone)){
                    phonenumberreg.setError("Harus 9 sampai 15 digit");
                }
                else {
                    smsManager.sendTextMessage(phone,
                            null,"Berikut kode OTP anda : " + a,
                            null, null);

                    Intent intent = new Intent(Register.this, confirmpage.class);
                    intent.putExtra("message",a);
                    intent.putExtra("username",username);
                    intent.putExtra("fullname",fullname);
                    intent.putExtra("password",password);
                    intent.putExtra("address",address);
                    intent.putExtra("email",email);
                    intent.putExtra("phone",phone);

                    startActivity(intent);

                }
            }
        });
    }


    public boolean chckemail(String emailuser){

        int x= 0;

        for(int a = 0; a< emailuser.length(); a++){
            if(emailuser.charAt(a) == '.'){
                x++;
            }
        }

        if(x>0)
            return false;
        else
            return true;
    }

    public boolean chckemail2(String emailuser){

        int x= 0;

        for(int a = 0; a< emailuser.length(); a++){
            if(emailuser.charAt(a) == '@'){
                x++;
            }
        }

        if(x>2 || x<1)
            return false;
        else
            return true;
    }

    public boolean chcknumber(String phone){
        int q = 0;
        for(int a=0; a<phone.length(); a++){
            if(Character.isDigit(phone.charAt(a))){
                q++;
            }
        }
        if(q<9 || q>15){
            return false;
        }
        else{
            return true;
        }
    }

    public boolean chckpassword(String password){
        int chck = 0,chck1 = 0,chck2 = 0;

        if(password.length() > 6){
            chck = 1;
        }

        for(int q = 0; q< password.length(); q++){
            if(Character.isUpperCase(password.charAt(q))){
                chck1++;
            }

            else if(Character.isLowerCase(password.charAt(q))){
                chck2++;
            }

        }
        if(chck > 0 && chck2 >0 && chck1 >0){
            return false;
        }
        else {
            return true;
        }
    }
}

