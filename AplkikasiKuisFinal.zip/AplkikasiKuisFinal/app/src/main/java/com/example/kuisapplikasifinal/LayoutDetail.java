package com.example.kuisapplikasifinal;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class LayoutDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout_detail);

        TextView nama, address, phonenumber;

        nama = findViewById(R.id.namaperpus);
        address = findViewById(R.id.alamatperpus);
        phonenumber = findViewById(R.id.phoneperpus);
    }
}

