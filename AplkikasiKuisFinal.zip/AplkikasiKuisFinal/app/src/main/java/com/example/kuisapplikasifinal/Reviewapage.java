package com.example.kuisapplikasifinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Reviewapage extends AppCompatActivity {
    Database db;
    DatabaseHelper dbh;
    Button delete;
    SQLiteDatabase dbb;
    ArrayList<Reviews> arrayreview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviewapage);
        db = new Database(this);
        String choose;
        arrayreview = db.viewUser();

        if(arrayreview.isEmpty()){
            db.insertReview(1,1,"gg","mantap boi");
            db.insertReview(1,1,"gg2","mantap boi 2");
            //arrayreview = db.viewUser();
        }

        ListView listView = findViewById(R.id.listview2);
        ListAdapter2 listAdapter = new ListAdapter2(this, arrayreview);
        listView.setAdapter(listAdapter);
    }
}
