package com.example.kuisapplikasifinal;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.database.Cursor;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {


    Database db;

   // ArrayList<Mahasiswa> datamahasiswa = new ArrayList<>();

    Register regis = new Register();

    String error;
    Button button;
   Button loginbtn2;
    private EditText name, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = (EditText) findViewById(R.id.usernametxt1);
        password = (EditText) findViewById(R.id.passwordtxt1);
        button = (Button) findViewById(R.id.regisbtn );
        loginbtn2 = (Button) findViewById(R.id.loginbtn);

        db= new Database(this);

        loginbtn2.setOnClickListener(this);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openactivityregis();
            }
        });
    }

    public void openactivityregis(){
        Intent intent = new Intent(this, Register.class);
        startActivity(intent);
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.loginbtn:
                String username = name.getText().toString();
                String password1 = password.getText().toString();
                Cursor c = db.cekLogin(username, password1);
                if(c.moveToFirst())
                {
                    Toast.makeText(this, "Success Login", 2000).show();
                    Intent main = new Intent(this,Home.class);
                    startActivity(main);
                    c.close();
                    finish();
                }
                else
                {
                    Toast.makeText(this,
                            "Username and Password invalid", 2000).show();
                }
                break;
        }
    }

}
