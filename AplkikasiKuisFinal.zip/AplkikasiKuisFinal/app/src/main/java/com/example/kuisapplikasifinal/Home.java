package com.example.kuisapplikasifinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Home extends AppCompatActivity {
    ArrayList<Perpustakaan> arrayyperpuss;
    private RequestQueue requestQueue;
    ListView listView;
    MenuItem reviewsitem;
    MenuItem logoutitem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        requestQueue = Volley.newRequestQueue(this);

        listView = findViewById(R.id.listview);

        String url = "https://api.myjson.com/bins/pobqg";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray resultArray = response.getJSONArray("data");
                    arrayyperpuss = new ArrayList<>();
                    for(int i = 0; i<resultArray.length(); i++){
                        JSONObject object = resultArray.getJSONObject(i);
                        String genre = "";
                        String a = "LibraryAddress";
                        int id = object.getInt("LibraryId");
                        String name = object.getString("LibraryName");
                        String alamat =  object.getString("LibraryAddress");
                        String nomor =    object.getString("LibraryPhone");
                        double latitude = object.getDouble("Latitude");
                        double longitude = object.getDouble("Longitude");

                        arrayyperpuss.add(new Perpustakaan(id,name,alamat,nomor,latitude,longitude));
                    }
                    ListAdapter listAdapter = new ListAdapter(Home.this, arrayyperpuss);
                    listView.setAdapter(listAdapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });
        requestQueue.add(request);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.example_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.item2:
                Intent main = new Intent(this,Reviewapage.class);
                startActivity(main);
                break;

            case R.id.item3:
                Intent main2 = new Intent(this, MainActivity.class);
                startActivity(main2);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}

