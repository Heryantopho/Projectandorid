package com.example.kuisapplikasifinal;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;

public class Database {
    SQLiteDatabase db;
    DatabaseHelper helper;
    Cursor cursor;
    public Database(Context context)
    {
        helper = new DatabaseHelper(context);
    }


    public void insertUser(String username,String fullname,String password,String address,String email,String phone){
        db = helper.getWritableDatabase();
        ContentValues value = new ContentValues();
        value.put(DatabaseHelper.MEMBER_USERNAME, username);
        value.put(DatabaseHelper.MEMBER_FULLNAME, fullname);
        value.put(DatabaseHelper.MEMBER_PASSWORD, password);
        value.put(DatabaseHelper.MEMBER_ADDRESS, address);
        value.put(DatabaseHelper.MEMBER_EMAIL, email);
        value.put(DatabaseHelper.MEMBER_PHONE, phone);
        db.insert(DatabaseHelper.TB_NAME, null, value);
    }

    public void insertReview(int memberId, int libraryId, String reviewtittle, String reviewdesc){
        db = helper.getWritableDatabase();
        ContentValues value = new ContentValues();
      //  value.put(DatabaseHelper.REVIEWS_REVIEWID,"1");
        value.put(DatabaseHelper.REVIEWS_MEMBERID, memberId);
        value.put(DatabaseHelper.REVIEWS_LIBRARYID, libraryId);
        value.put(DatabaseHelper.REVIEWS_REVIEWTITTLE, reviewtittle);
        value.put(DatabaseHelper.REVIEWS_REVIEWDESCRIPTION, reviewdesc);
        db.insert(DatabaseHelper.TB_NAME2,null, value);
        /*
        value.put(DatabaseHelper.REVIEWS_REVIEWID,"2");
        value.put(DatabaseHelper.REVIEWS_MEMBERID,"2");
        value.put(DatabaseHelper.REVIEWS_LIBRARYID,"2");
        value.put(DatabaseHelper.REVIEWS_REVIEWTITTLE,"Gg");
        value.put(DatabaseHelper.REVIEWS_REVIEWDESCRIPTION,"This library have a complete series of books");
*/
    }

    public Cursor cekLogin(String username, String password){
        db = helper.getReadableDatabase();
        cursor = db.query
                (
                        DatabaseHelper.TB_NAME,
                        new String[]{DatabaseHelper.MEMBER_MEMBERID, DatabaseHelper.MEMBER_USERNAME,
                                DatabaseHelper.MEMBER_PASSWORD},
                        new String(DatabaseHelper.MEMBER_USERNAME + " = ? AND " +
                                DatabaseHelper.MEMBER_PASSWORD+ " = ?"),
                        new String[]{username,password},
                        null,
                        null,
                        null
                );
        return cursor;
    }


    public ArrayList<Reviews>viewUser(){
        ArrayList<Reviews> userList = new ArrayList<>();
        String selectQuery =
                "Select "+
                        DatabaseHelper.REVIEWS_REVIEWID+","+
                        DatabaseHelper.REVIEWS_MEMBERID+","+
                        DatabaseHelper.REVIEWS_LIBRARYID+","+
                        DatabaseHelper.REVIEWS_REVIEWTITTLE+","+
                        DatabaseHelper.REVIEWS_REVIEWDESCRIPTION+" from "+
                        DatabaseHelper.TB_NAME2+"";
        db = helper.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        //buat mengambil data dari database dan set data ke dalam array
        if (cursor.moveToFirst()) {
            do {
                Reviews user = new Reviews();
                user.setRevid(cursor.getInt(0));
                user.setId(cursor.getInt(1));
                user.setLibid(cursor.getInt(2));
                user.setReviewtittle(cursor.getString(3));
                user.setReviewdesc(cursor.getString(4));
                userList.add(user);
            } while (cursor.moveToNext());
        }
        return userList;

    }

    public void deleteReviews(int id)
    {
        db = helper.getWritableDatabase();
        db.delete(DatabaseHelper.TB_NAME2, "ReviewID=?",
                new String[]{""+id});
    }

}