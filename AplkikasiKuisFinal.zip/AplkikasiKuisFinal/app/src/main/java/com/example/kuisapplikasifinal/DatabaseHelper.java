package com.example.kuisapplikasifinal;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "myDB.db";
    public static final String TB_NAME = "Member";
    public static final String TB_NAME2 = "Reviews";
    public static final String TB_NAME3 = "Library";
    public static final int DB_VERSION = 1;

    public static final String MEMBER_MEMBERID = "MemberID";
    public static final String MEMBER_USERNAME = "Username";
    public static final String MEMBER_FULLNAME = "Fullname";
    public static final String MEMBER_PASSWORD = "Password";
    public static final String MEMBER_ADDRESS = "Address";
    public static final String MEMBER_EMAIL = "Email";
    public static final String MEMBER_PHONE = "Phone";

    public static final String REVIEWS_REVIEWID = "ReviewID";
    public static final String REVIEWS_MEMBERID = "MemberID";
    public static final String REVIEWS_LIBRARYID = "LibraryID";
    public static final String REVIEWS_REVIEWTITTLE = "ReviewTittle";
    public static final String REVIEWS_REVIEWDESCRIPTION = "ReviewDescription";

    public static final String LIBRARY_LIBRARYID = "LibraryID";
    public static final String LIBRARY_LIBRARYNAME = "LibraryName";
    public static final String LIBRARY_LIBRARYADDRESS = "LibraryAddress";
    public static final String LIBRARY_LIBRARYPHONE = "LibraryPhone";
    public static final String LIBRARY_LATITUDE = "Latitude";
    public static final String LIBRARY_LONGITUDE = "Longitude";


    public DatabaseHelper(Context context) {
        super(context, DB_NAME,null, DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL
                (
                        "CREATE TABLE IF NOT EXISTS "+TB_NAME+
                                "("+
                                MEMBER_MEMBERID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
                                MEMBER_USERNAME+" TEXT NOT NULL, "+
                                MEMBER_FULLNAME+" TEXT NOT NULL,"+
                                MEMBER_PASSWORD+" TEXT NOT NULL, "+
                                MEMBER_ADDRESS+" TEXT NOT NULL, "+
                                MEMBER_EMAIL+" TEXT NOT NULL, "+
                                MEMBER_PHONE+" TEXT NOT NULL "+
                                ")"
                );
        db.execSQL
                (
                        "CREATE TABLE IF NOT EXISTS " + TB_NAME2 +
                                "(" +
                                REVIEWS_REVIEWID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                                REVIEWS_MEMBERID + " INTEGER NOT NULL, " +
                                REVIEWS_LIBRARYID + " INTEGER NOT NULL, "+
                                REVIEWS_REVIEWTITTLE+ " TEXT NOT NULL, "+
                                REVIEWS_REVIEWDESCRIPTION + " TEXT NOT NULL, "+
                                "FOREIGN KEY ("+REVIEWS_MEMBERID+") REFERENCES "+
                                TB_NAME+"("+MEMBER_MEMBERID+")"+
                                ")"
                );

        db.execSQL
                (
                        "CREATE TABLE IF NOT EXISTS " + TB_NAME3 +
                                "(" +
                                LIBRARY_LIBRARYID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                                LIBRARY_LIBRARYNAME + " TEXT NOT NULL, " +
                                LIBRARY_LIBRARYADDRESS + " TEXT NOT NULL, "+
                                LIBRARY_LIBRARYPHONE+ " TEXT NOT NULL, "+
                                LIBRARY_LATITUDE + " TEXT NOT NULL, "+
                                LIBRARY_LONGITUDE + " TEXT NOT NULL "+
                                ")"
                );

        db.execSQL
                (
                        "INSERT OR IGNORE INTO " +TB_NAME+ " VALUES (1,'qq','admin','benar','address','asdfaa','12')"
                );

        db.execSQL
                (
                        "INSERT OR IGNORE INTO " +TB_NAME+ " VALUES (2,'samsq','admin','ea','address','asdfaa','12')"
                );


    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TB_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+TB_NAME2);
        db.execSQL("DROP TABLE IF EXISTS "+TB_NAME3);
        onCreate(db);
    }
}
