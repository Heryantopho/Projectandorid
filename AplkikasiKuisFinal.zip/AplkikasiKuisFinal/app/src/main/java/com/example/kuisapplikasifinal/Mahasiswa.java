package com.example.kuisapplikasifinal;

public class Mahasiswa {
    int id;
    String username;
    String fullname;
    String password;
    String address;
    String email;
    String phone;

    public Mahasiswa(int id, String username, String fullname, String password, String address, String email, String phone){
        super();
        this.id = id;
        this.username = username;
        this.fullname = fullname;
        this.password =  password;
        this.address = address;
        this.email = email;
        this.phone = phone;
    }

    public String getUsername(){
        return username;
    }

    public String  getPassword(){
        return password;
    }

}

