package com.example.kuisapplikasifinal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class confirmpage extends AppCompatActivity {


    ArrayList<Mahasiswa> datamahasiswa = new ArrayList<>();
    Register regis = new Register();
    TextView confirm;
    Button btnconfirm;
    String kode, kode2;
    Database db;
    public void setText(String kode2){
        this.kode2 = kode2;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        db = new Database(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmpage);
        regis.mahasiswaArray = datamahasiswa;


        confirm = findViewById(R.id.txtconfirm);
        btnconfirm = findViewById(R.id.btnconfirm);

        Bundle bundle = getIntent().getExtras();
        final String message = bundle.getString("message");
        final String username = bundle.getString("username");
        final String fullname = bundle.getString("fullname");
        final String password = bundle.getString("password");
        final String address = bundle.getString("address");
        final String email = bundle.getString("email");
        final String phone = bundle.getString("phone");

        btnconfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                kode = confirm.getText().toString();
                if(kode.equals(message)){
                    //Toast.makeText(confirmpage.this, "benar", Toast.LENGTH_SHORT).show();
//                    String username1 = null,fullname1 = null,password1 = null,address1 = null,email1 = null,phone1 = null;

                   db.insertUser(username,fullname,password,address,email,phone);

                    Toast.makeText(getApplicationContext(),"Register Success",
                            Toast.LENGTH_LONG).show();

                    Intent intent = new Intent(confirmpage.this, Home.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(confirmpage.this, "Kode konfirmasi salah", Toast.LENGTH_SHORT).show();
                }
            }

        });
    }
}
