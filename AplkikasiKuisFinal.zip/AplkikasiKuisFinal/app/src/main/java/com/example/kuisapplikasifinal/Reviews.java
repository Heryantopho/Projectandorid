package com.example.kuisapplikasifinal;

public class Reviews {
int revid;
int id;
int libid;
String reviewtittle;
String reviewdesc;

    /*
        public Reviews(int revid,int id,int libid,String reviewtittle,String reviewdesc){
            super();
            this.revid = revid;
            this.id = id;
            this.libid = libid;
            this.reviewtittle = reviewtittle;
            this.reviewdesc =  reviewdesc;
        }
    */

    public Reviews(){

    }

    public void setRevid(int revid) {
        this.revid = revid;
    }

    public void setLibid(int libid) {
        this.libid = libid;
    }

    public void setReviewtittle(String reviewtittle) {
        this.reviewtittle = reviewtittle;
    }

    public void setReviewdesc(String reviewdesc) {
        this.reviewdesc = reviewdesc;
    }

    public void setId(int revid) {
        this.libid = revid;
    }

    public int getId() {
        return revid;
    }

    public String getReviewtittle() {
        return reviewtittle;
    }

    public String getReviewdesc(){
        return reviewdesc;
    }


}
