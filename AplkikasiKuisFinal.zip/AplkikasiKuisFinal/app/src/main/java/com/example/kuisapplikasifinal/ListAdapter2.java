package com.example.kuisapplikasifinal;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class ListAdapter2 extends BaseAdapter {
    Database db;
    private Context context;
    private ArrayList<Reviews> listReviews = new ArrayList<>();

    public ListAdapter2(Context context, ArrayList<Reviews> listReviews) {
        this.context = context;
        this.listReviews = listReviews;
    }

    @Override
    public int getCount() {
        return listReviews.size();
    }

    @Override
    public Object getItem(int i) {
        return listReviews.get(i);
    }

    @Override
    public long getItemId(int i) {
        return listReviews.get(i).getId();
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        view = LayoutInflater.from(context).inflate(R.layout.item_row, viewGroup, false);

      //  back = (Button)findViewById(R.id.button2);

        db = new Database(context);


        TextView title = view.findViewById(R.id.title);
        TextView desc = view.findViewById(R.id.desc);
        Button deleteButton = view.findViewById(R.id.delete_btn);

        title.setText(listReviews.get(i).getReviewtittle());
        desc.setText(listReviews.get(i).getReviewdesc());
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final int position = i;
                AlertDialog.Builder builder =
                        new AlertDialog.Builder(context);
                builder.setMessage("Yakin mau hapus?");
                builder.setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                db.deleteReviews(position);
                                listReviews.remove(position);
                                notifyDataSetChanged();
                            }
                        });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        return view;
    }
}