package com.example.kuisapplikasifinal;

import android.location.Address;

public class Perpustakaan {

    int libid;
    String libname;
    double latitude, longtitude;
    String libaddress,libphone;

    public Perpustakaan(int libid, String libname, String libaddress, String libphone, double latitude, double longtitude){
        this.libid = libid;
        this.libname = libname;
        this.libaddress = libaddress;
        this.libphone = libphone;
        this.latitude = latitude;
        this.longtitude = longtitude;
    }

    public void setId(int libid) {
        this.libid = libid;
    }

    public int getId() {
        return libid;

    }

    public String getLibname() {
        return libname;
    }

    public String getLibphone(){
        return libphone;
    }

    public void setLibname(String Libname) {
        this.libname = libname;
    }

    public String getAddress() {
        return libaddress;
    }

    public void setLibaddress(String libaddress) {
        this.libaddress = libaddress;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongtitude() {
        return longtitude;
    }
}