package com.example.kuisapplikasifinal;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import static androidx.core.content.ContextCompat.startActivity;

public class ListAdapter extends BaseAdapter {
    Database db;
    Context context;
    private ArrayList<Perpustakaan> listPerpuss = new ArrayList<>();
    double lat = 0;
    double longt = 0;

    public ListAdapter(Context context, ArrayList<Perpustakaan> listPerpuss) {
        this.context = context;
        this.listPerpuss = listPerpuss;
    }

    @Override
    public int getCount() {
        return listPerpuss.size();
    }

    @Override
    public Object getItem(int i) {
        return listPerpuss.get(i);
    }

    @Override
    public long getItemId(int i) {
        return listPerpuss.get(i).getId();
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
        view = LayoutInflater.from(context).inflate(R.layout.item_row, viewGroup, false);

        TextView title = view.findViewById(R.id.title);
        TextView desc = view.findViewById(R.id.desc);
        Button deleteButton = view.findViewById(R.id.delete_btn);

        title.setText(listPerpuss.get(i).getLibname());
        desc.setText(listPerpuss.get(i).getAddress());

        lat = listPerpuss.get(i).getLatitude();
        longt = listPerpuss.get(i).getLongtitude();
        
        deleteButton.setText("Location");

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Intent intent = new Intent(context, GoogleMaps.class);

                intent.putExtra("lat",lat);
                intent.putExtra("longt", longt);
                context.startActivity(intent);
            }
        });

        return view;
    }
}

